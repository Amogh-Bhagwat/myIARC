#include "opencv2/core.hpp"
#include "opencv2/imgproc.hpp"
#include "opencv2/imgcodecs.hpp"
#include "opencv2/highgui.hpp"
#include <iostream>
#include <math.h>
#include <string.h>
#include <ros/ros.h>
#include <cv_bridge/cv_bridge.h>
#include <sensor_msgs/image_encodings.h>
#include "geometry_msgs/Point.h"

using namespace cv;
using namespace std;

geometry_msgs::Point boxcentre;
ros::Publisher pub;

int thresh = 50, N = 10;

static double angle( Point pt1, Point pt2, Point pt0 )
{
    double dx1 = pt1.x - pt0.x;
    double dy1 = pt1.y - pt0.y;
    double dx2 = pt2.x - pt0.x;
    double dy2 = pt2.y - pt0.y;
    return (dx1*dx2 + dy1*dy2)/sqrt((dx1*dx1 + dy1*dy1)*(dx2*dx2 + dy2*dy2) + 1e-10);
}

static void findBoxes( const Mat& image, vector<vector<Point> >& squares )
{
    squares.clear();

    Mat gray0(image.size(), CV_8U), gray;  

    vector<vector<Point> > contours;
    gray0 = image;      
       
    Canny(gray0, gray, 0, thresh, 5);               
    dilate(gray, gray, Mat(), Point(-1,-1)); 
         
    findContours(gray, contours, RETR_LIST, CHAIN_APPROX_SIMPLE);
    vector<Point> approx;
    for( size_t i = 0; i < contours.size(); i++ )
    {                
        approxPolyDP(Mat(contours[i]), approx, arcLength(Mat(contours[i]), true)*0.02, true);
        if( approx.size() == 4 && fabs(contourArea(Mat(approx))) > 1600 &&   isContourConvex(Mat(approx)) )
        {
            double maxCosine = 0;

            for( int j = 2; j < 5; j++ )
            {                        
                double cosine = fabs(angle(approx[j%4], approx[j-2], approx[j-1]));
                maxCosine = MAX(maxCosine, cosine);
            }
            if( maxCosine < 0.3 )
            {
                squares.push_back(approx);
                cout<<"Square detected"<<endl;
                cv::Moments m = moments(squares, true);
                boxcentre.x = m.m10/m.m00;
                boxcentre.y = m.m01/m.m00;
                boxcentre.z = 0;
                pub.publish(boxcentre);

            }
        }
    } 
}

void callback(const sensor_msgs::ImageConstPtr& msg)
{
    cv_bridge::CvImagePtr cv_ptr;
    try
    {
      cv_ptr = cv_bridge::toCvCopy(msg, sensor_msgs::image_encodings::BGR8);
    }
    catch (cv_bridge::Exception& e)
    {
      ROS_ERROR("cv_bridge exception: %s", e.what());
      return;
    }

    Mat image = cv_ptr->image;

    Mat output;    
    inRange(image, Scalar(0, 0, 0), Scalar(50, 50, 50), output); 

    cvtColor(output,output,COLOR_GRAY2BGR);
    
        
        vector<vector<Point> > squares;
            findBoxes(output, squares);       

}

int main (int argc, char** argv)
{
    
    ros::init (argc, argv, "box centres");
    
    ros::NodeHandle nh;
    ros::Subscriber sub1 = nh.subscribe ("/camera/rgb/image_raw", 1, callback);   

    pub = nh.advertise<geometry_msgs::Point>("/boxCentre", 1);

    ros::spin();
     
    return 0;
}